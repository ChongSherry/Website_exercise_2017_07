module.exports={
    db_connection:"mongodb://127.0.0.1:27017/website",
    modalPath:"./app/db_mod"
}